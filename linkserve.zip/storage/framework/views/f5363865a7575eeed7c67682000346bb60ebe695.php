<?php $__env->startSection('content'); ?>  
<section class="well1 ins2 mobile-center">
  <div class="container">

    <div class="col-sm-12 custom_blank_space">
      <br><br>
      <h2><?php echo e($post->post_title); ?></h2>
      <br><br>

      <?php if($post->preview_image != ""): ?>
        <img  class="img-responsive" src="<?php echo e(asset(Storage::url($post->preview_image))); ?>" alt="">
      <?php endif; ?>

      
        <?php echo $post->post_content; ?>


      
    </div>

  </div>
</section>				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>