<?php $__env->startSection('content'); ?>  
<div class="row">
	<div class="col-sm-8 col-sm-offset-2 col-xs-12">

		<div class="x_panel">
			<div class="x_title">
				<h2 style="text-transform: uppercase;">Add New 4 Home Block</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<br />
				<?php echo Form::open(["url"=> url('admin/storeHomeBlock'), "id" => "demo-form2", "files" => true, "class" => "form-horizontal form-label-left form-group", "data-parsley-validate row" => ""]); ?>


					    <?php echo e(Form::label('post_title', 'Post Title 1 :')); ?>

					    <?php echo e(Form::text('post_title_1', null, array("class" => "form-control", "maxlength" => "191" ))); ?>

					    <br>

					    <?php echo e(Form::label('post_content', 'Content 1 :', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::text('post_content_1', null, array("class" => "form-control" ))); ?>

					    <br>		

						<?php echo e(Form::label('post_title', 'Post Title 2 :')); ?>

					    <?php echo e(Form::text('post_title_2', null, array("class" => "form-control", "maxlength" => "191" ))); ?>

					    <br>

					    <?php echo e(Form::label('post_content', 'Content 2 :', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::text('post_content_2', null, array("class" => "form-control" ))); ?>

					    <br>		

						<?php echo e(Form::label('post_title', 'Post Title 3 :')); ?>

					    <?php echo e(Form::text('post_title_3', null, array("class" => "form-control", "maxlength" => "191" ))); ?>

					    <br>

					    <?php echo e(Form::label('post_content', 'Content 3 :', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::text('post_content_3', null, array("class" => "form-control" ))); ?>

					    <br>		

						<?php echo e(Form::label('post_title', 'Post Title 4 :')); ?>

					    <?php echo e(Form::text('post_title_4', null, array("class" => "form-control", "maxlength" => "191" ))); ?>

					    <br>

					    <?php echo e(Form::label('post_content', 'Content 4 :', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::text('post_content_4', null, array("class" => "form-control" ))); ?>

					    <br>		



					    <?php echo e(Form::submit('Create', array('class' => 'btn btn-lg btn-block btn-primary form-margin'))); ?>


				<?php echo Form::close(); ?>


			</div>
		</div>


	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>