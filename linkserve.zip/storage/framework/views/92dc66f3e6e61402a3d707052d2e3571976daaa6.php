<?php $__env->startSection('content'); ?>  


<style type="text/css">
	.hide-bullets {
	    list-style:none;
	    margin-left: -40px;
	    margin-top:20px;
	}

	.thumbnail {
	    padding: 0;
	}

	.carousel-inner>.item>img, .carousel-inner>.item>a>img {
	    width: 100%;
	}	
</style>
<?php
	$files = explode(",",$post->files);
?>



<div class="container">
    <div id="main_area">

    	<div class="row">
    		<div class="col-sm-12">
		      <br><br>
		      <h2 class="text-center"><?php echo e($post->post_title); ?></h2>
		      <br><br>    			
    		</div>
    	</div>


    	<div class="row">
    		<div class="col-sm-9">
				<?php echo $post->post_content; ?>

    		</div>
    		<div class="col-sm-3">
    			<h3>Files to downlaod:</h3>
            	<?php $cnt = 1;?>
            	<ul>
            	<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-center">
                        <a class="thumbnail downlaod-file" href="<?php echo e(asset(Storage::url($file))); ?>" download>
                            <i class="fa fa-download" aria-hidden="true"></i> File - <?php echo e($cnt); ?>

                        </a>
                    </li>
                    <?php $cnt++;?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
    		</div>
    	</div>


    </div>
</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>