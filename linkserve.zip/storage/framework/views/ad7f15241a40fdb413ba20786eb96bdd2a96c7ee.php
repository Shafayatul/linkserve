<?php $__env->startSection('content'); ?>  
<section class="well1 ins2 mobile-center">
  <div class="container">

    <div class="col-sm-12" id="partners">


      <br><br>
      <h2><?php echo e($partners->post_title); ?></h2>
      <br><br>
      <?php if($partners->preview_image != ""): ?>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($partners->preview_image))); ?>" alt="">
      <?php endif; ?>
      
        <?php echo $partners->post_content; ?>


      
    </div>

    <br>
    <hr>
    <br>

    <div class="col-sm-12" id="clients">
      <h2><?php echo e($clients->post_title); ?></h2>
      <br><br>
      <?php if($clients->preview_image != ""): ?>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($clients->preview_image))); ?>" alt="">
      <?php endif; ?>
      
        <?php echo $clients->post_content; ?>


      
    </div>



  </div>
</section>				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>