<?php $__env->startSection('content'); ?>  
<div class="row">
	<div class="col-sm-10 col-sm-offset-1">

		<div class="x_panel">
			<div class="x_title">
				<h2 style="text-transform: uppercase;">List: <?php echo e(str_replace("_"," ", str_replace("f__", "", $type) )); ?></h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">

				<div class="table-responsive">
				  <table class="table table-bordered table-text-center">
				     <thead>
				      <tr>
				        <th class="post_title">Title</th>
				        <th class="post_content">Body</th>
				        <th class="preview_image">Image</th>
				        <th>Action</th>
				      </tr>
				    </thead>

				    <tbody>
    				    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr id="row_<?php echo e($post->id); ?>">
								<th class="post_title">
									<?php echo e($post->post_title); ?>

								</th>
								<th class="post_content">
									<?php echo substr($post->post_content, 0, 200); ?>

						            <?php if(strlen($post->post_content) >200): ?>
						              ...
						            <?php endif; ?>
								</th>
								<th class="preview_image">
									<?php if($post->preview_image != ""): ?>
							        	<img src="<?php echo e(asset(Storage::url($post->preview_image))); ?>" alt="" width="70px" class="img-thumbnail">
							        <?php endif; ?>
			      				</th>
								<th>
									<button type="button" class="btn btn-danger post-delete-button" id="<?php echo e($post->id); ?>">
										<i class="fa fa-trash-o" aria-hidden="true"></i>
									</button>
								</th>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    </tbody>

				  </table>
				</div>			    


			    <div class="text-center">
			    <?php echo $posts->links();; ?>

			    </div>


			</div>
		</div>


	</div>
</div>

<input type="hidden" class="post_type_class" value="<?php echo e($type); ?>">


<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_page_script'); ?>
	<script type="text/javascript">
		$(document).ready(function(){

			var postType = $(".post_type_class").val();

			if(postType == "slider"){
				$(".post_content").hide();
			}else if(postType == "service"){
				$(".preview_image").hide();
			}else if(postType == "contact"){
				$(".preview_image").hide();
			}

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>