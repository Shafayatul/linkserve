<?php $__env->startSection('content'); ?>  
<div class="row">
	<div class="col-sm-12" style="min-height: 100vh">

		<br>
		<br>
		<br>
		<br>
		<h1 class="welcome-text"> Welcome To <br> <br> Link Serve Admin</h1>


	</div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>