<?php $__env->startSection('content'); ?>  
<section class="well1 ins2 mobile-center">
  <div class="container">

    <div class="col-sm-12" id="male_shop">


      <br><br>
      <h2><?php echo e($male_shop->post_title); ?></h2>
      <br><br>
      <?php if($male_shop->preview_image != ""): ?>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($male_shop->preview_image))); ?>" alt="">
      <?php endif; ?>
      
        <?php echo $male_shop->post_content; ?>


      
    </div>

    <br>
    <hr>
    <br>

    <div class="col-sm-12" id="Hulhumale">
      <h2><?php echo e($Hulhumale->post_title); ?></h2>
      <br><br>
      <?php if($Hulhumale->preview_image != ""): ?>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($Hulhumale->preview_image))); ?>" alt="">
      <?php endif; ?>
      
        <?php echo $Hulhumale->post_content; ?>


      
    </div>

    <br>
    <hr>
    <br>

    <div class="col-sm-12" id="Kulhudhuffushi">
      <h2><?php echo e($Kulhudhuffushi->post_title); ?></h2>
      <br><br>
      <?php if($Kulhudhuffushi->preview_image != ""): ?>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($Kulhudhuffushi->preview_image))); ?>" alt="">
      <?php endif; ?>
      
        <?php echo $Kulhudhuffushi->post_content; ?>


      
    </div>

    <br>
    <hr>
    <br>

    <div class="col-sm-12" id="addu_city">
      <h2><?php echo e($addu_city->post_title); ?></h2>
      <br><br>
      <?php if($addu_city->preview_image != ""): ?>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($addu_city->preview_image))); ?>" alt="">
      <?php endif; ?>
      
        <?php echo $addu_city->post_content; ?>


      
    </div>



  </div>
</section>				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>