<?php $__env->startSection('content'); ?>  
<section class="well1 ins2 mobile-center">
  <div class="container">
    <h2 style="text-transform: uppercase;"><?php echo e(str_replace("_"," ",$type)); ?> :</h2>
    <hr>
    <br><br>
	
    <?php $cnt=0;?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($cnt%3==0): ?>
        <div class="row ">
      <?php endif; ?>

        <div class="col-sm-4 custom_blank_space">
          <?php if($post->preview_image != ""): ?>
          <img src="<?php echo e(asset(Storage::url($post->preview_image))); ?>" alt="">
          <?php endif; ?>
          <h3><?php echo e($post->post_title); ?></h3>
          <p class="text-justify">
            <?php echo substr($post->post_content, 0, 200); ?>

            <?php if(strlen($post->post_content) >200): ?>
              ...
            <?php endif; ?>
          </p><a href="<?php echo url('download/'.$post->id); ?>" class="btn ">See Detail</a>
        </div>

      <?php $cnt++;?>
      <?php if(($cnt%3==0) && (!$loop->last)): ?>
        </div>
        <hr class="hide_in_mobile">
      <?php elseif(($cnt%3 != 0) && ($loop->last)): ?>
        </div>
      <?php endif; ?>
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="text-center">
    <?php echo $posts->links();; ?>

    </div>



  </div>
</section>				

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_front_page_script'); ?>
<script type="text/javascript">

  $(document).ready(function(){

     if ($(window).width() < 768){
      $(".hide_in_mobile").hide();
      $(".custom_blank_space").append("<hr>");

     }

  });  

</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>