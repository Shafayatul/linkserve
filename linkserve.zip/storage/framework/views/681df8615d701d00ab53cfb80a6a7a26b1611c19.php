<?php $__env->startSection('content'); ?>  

  <section class="camera_container">
    <div id="camera" class="camera_wrap">

      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div data-src="<?php echo e(asset(Storage::url($slider->preview_image))); ?>">
        <div class="camera_caption fadeIn">
          <div class="container">
            <div class="row">
              <div class="preffix_6 col-sm-6"><center><?php echo e($slider->post_title); ?></center></div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </section>

  
  <section>
    <div class="container banner_wr">
      <ul class="banner">
        <center>
          <li><br>
            <div class="fa-sun-o"></div>
            <h3>Renewable<br/>Energy</h3>

          </li>
          <li><br>
            <div class="fa-unlock-alt"></div>
            <h3>Security<br/>Solutions</h3>

          </li>
          <li><br>
            <div class="fa-file"></div>
            <h3>Software<br/>solutions</h3>

          </li>
          <li><br>
            <div class="fa-connectdevelop"></div>
            <h3>Networking<br/>Solutions</h3>

          </li>

          <li>
            <div class="fa-database"></div>
            <h3>Server Storage & <br/>Backup Solutions</h3>

          </li>

          <li><br>
            <div class="fa-fire"></div>
            <h3>Firewall<br/>Solutions</h3>

          </li>

          <li><br>
            <div class="fa-cogs"></div>
            <h3>Integrated<br/>Solutions</h3>

          </li>

        </center>


      </ul>
    </div>
  </section>
  <section class="well ins1">
    <div class="container hr">
      <ul class="row product-list">
        <li class="col-sm-6">
          <div class="box wow fadeInRight">
            <div class="box_aside">
              <div class="icon fa-comments"></div>
            </div>
            <div class="box_cnt__no-flow">
              <h3><a href="#"><?php echo e($home_block_1->post_title); ?></a></h3>
              <?php echo e($home_block_1->post_content); ?>

            </div>
          </div>
          <hr>
          <div data-wow-delay="0.2s" class="box wow fadeInRight">
            <div class="box_aside">
              <div class="icon fa-calendar-o"></div>
            </div>
            <div class="box_cnt__no-flow">
              <h3><a href="#"><?php echo e($home_block_2->post_title); ?></a></h3>
              <?php echo e($home_block_2->post_content); ?>

            </div>
          </div>
        </li>
        <li class="col-sm-6">
          <div data-wow-delay="0.3s" class="box wow fadeInRight">
            <div class="box_aside">
              <div class="icon fa-group"></div>
            </div>
            <div class="box_cnt__no-flow">
              <h3><a href="#"><?php echo e($home_block_3->post_title); ?></a></h3>
              <?php echo e($home_block_3->post_content); ?>

            </div>
          </div>
          <hr>
          <div data-wow-delay="0.4s" class="box wow fadeInRight">
            <div class="box_aside">
              <div class="icon fa-thumbs-up"></div>
            </div>
            <div class="box_cnt__no-flow">
              <h3><a href="#"><?php echo e($home_block_4->post_title); ?></a></h3>
              <?php echo e($home_block_4->post_content); ?>

            </div>
          </div>
        </li>
      </ul>
    </div>
  </section>
  <section class="well1">
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
            <h2><?php echo e($about->post_title); ?></h2><img src="<?php echo e(asset(Storage::url($about->preview_image))); ?>" alt="" style="border: #57aacd 1px solid;">
            <p class="text-justify">
              <?php echo $about->post_content; ?>

            </p>
        </div>
        <div class="col-sm-4">
          <h2><?php echo e($service->post_title); ?></h2>
          <?php echo $service->post_content; ?>

          <br><br>



          
          <div class="owl-carousel">
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
              <blockquote class="box">
                <div class="box_aside"><img src="<?php echo e(asset(Storage::url($testimonial->preview_image))); ?>" alt=""></div>
                <div class="box_cnt__no-flow">
                  <p>
                    <q><?php echo $testimonial->post_content; ?></q>
                  </p>
                  <cite><a href="#"><?php echo e($testimonial->post_title); ?></a></cite>
                </div>
              </blockquote>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>

       


        <div class="col-sm-4">
          <div class="info-box">
            <h2 class="fa-comment">Request Quote</h2>
            <hr>
            <h3>Ask professionals:</h3>
            <dl>
              <dt>Monday - Friday:</dt>
              <dd>8am-7pm</dd>
            </dl>
            <dl>
              <dt>Saturday:</dt>
              <dd>8am-5pm</dd>
            </dl>
            <dl>
              <dt>Sunday:</dt>
              <dd>1pm-5pm</dd>
            </dl>
            <hr>
            <h3>24/7 Online Support:</h3>
            <dl>
              <dt>800-2345-6789</dt>
            </dl>
          </div>


          <div class="owl-carousel">
            <?php $__currentLoopData = $team_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team_member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="item">
                <blockquote class="box">
                 <center>     <cite><a href=""><?php echo e($team_member->post_title); ?></a></cite></center>
                 <img src="<?php echo e(asset(Storage::url($team_member->preview_image))); ?>" alt="">
                 <div class="box_cnt__no-flow">

                  <center><cite><a href=""><?php echo $team_member->post_content; ?></a></cite></center>  
                </div>
              </blockquote>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>