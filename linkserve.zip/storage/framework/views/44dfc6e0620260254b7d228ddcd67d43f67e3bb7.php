<?php $__env->startSection('content'); ?>  
<section class="well1 ins2 mobile-center">
  <div class="container">

    <div class="col-sm-12" id="f__guarantees_warranties">


      <br><br>
      <h2><?php echo e($f__guarantees_warranties->post_title); ?></h2>
      <br><br>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($f__guarantees_warranties->preview_image))); ?>" alt="">
      <p class="text-justify">
        <?php echo $f__guarantees_warranties->post_content; ?>


      </p>
    </div>

    <br>
    <hr>
    <br>

    <div class="col-sm-12" id="f__goods_return_policy">
      <h2><?php echo e($f__goods_return_policy->post_title); ?></h2>
      <br><br>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($f__goods_return_policy->preview_image))); ?>" alt="">
      <p class="text-justify">
        <?php echo $f__goods_return_policy->post_content; ?>


      </p>
    </div>

    <br>
    <hr>
    <br>

    <div class="col-sm-12" id="f__career">
      <h2><?php echo e($f__career->post_title); ?></h2>
      <br><br>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($f__career->preview_image))); ?>" alt="">
      <p class="text-justify">
        <?php echo $f__career->post_content; ?>


      </p>
    </div>

    <br>
    <hr>
    <br>

    <div class="col-sm-12" id="f__job_opportunities">
      <h2><?php echo e($f__job_opportunities->post_title); ?></h2>
      <br><br>
      <img  class="img-responsive" src="<?php echo e(asset(Storage::url($f__job_opportunities->preview_image))); ?>" alt="">
      <p class="text-justify">
        <?php echo $f__job_opportunities->post_content; ?>


      </p>
    </div>



  </div>
</section>				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>