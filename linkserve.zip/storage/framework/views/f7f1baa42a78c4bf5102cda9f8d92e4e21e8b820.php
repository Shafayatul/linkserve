<?php $__env->startSection('content'); ?>  
<div class="row">
	<div class="col-sm-8 col-sm-offset-2 col-xs-12">

		<div class="x_panel">
			<div class="x_title">
				<h2>Add Article</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<br />
				<?php echo Form::open(["route"=>"posts.store", "id" => "demo-form2", "files" => true, "class" => "form-horizontal form-label-left form-group", "data-parsley-validate row" => ""]); ?>


					    <?php echo e(Form::label('post_title', 'Post Title:')); ?>

					    <?php echo e(Form::text('post_title', null, array("class" => "form-control", "required" => "required", "maxlength" => "191" ))); ?>

					    <br>

					    <?php echo e(Form::label('post_type', 'Select Post Type:', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::select('post_type', array('News' => 'News', 'Advertorials' =>'Advertorials' ),
						   null,
						   array("class" => "form-control", "required" => "required" ) 
						)); ?>

						<br>


					    <?php echo e(Form::label('post_content', 'content', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::textarea('post_content', null, array("class" => "form-control"))); ?>

					    <br>


					    <?php echo e(Form::label('file', 'Preview Image:', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::file('file', null, array("class" => "form-control", "required" => "required", "maxlength" => "10" ))); ?>		
					    <br>				

					    <?php echo e(Form::submit('Create', array('class' => 'btn btn-lg btn-block btn-primary form-margin'))); ?>


				<?php echo Form::close(); ?>


			</div>
		</div>


	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>