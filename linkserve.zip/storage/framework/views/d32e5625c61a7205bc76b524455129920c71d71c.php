<?php $__env->startSection('content'); ?>  
<section class="well1 ins2 mobile-center">
  <div class="container">

    <div class="row">
      <div class="col-sm-12" id="about_us">

        <br><br>
        <h2><?php echo e($about_us->post_title); ?></h2>
        <br><br>
        <?php if($about_us->preview_image != ""): ?>
        <img  class="img-responsive" src="<?php echo e(asset(Storage::url($about_us->preview_image))); ?>" alt="">
        <?php endif; ?>
        
          <?php echo $about_us->post_content; ?>


        
      </div>

      <br>
      <hr>
      <br>

      <div class="col-sm-12" id="mission">
        <h2><?php echo e($mission->post_title); ?></h2>
        <br><br>
        <?php if($mission->preview_image != ""): ?>
        <img  class="img-responsive" src="<?php echo e(asset(Storage::url($mission->preview_image))); ?>" alt="">
        <?php endif; ?>
        
          <?php echo $mission->post_content; ?>


        
      </div>

      <br>
      <hr>
      <br>

      <div class="col-sm-12" id="vision">
        <h2><?php echo e($vision->post_title); ?></h2>
        <br><br>
        <?php if($vision->preview_image != ""): ?>
        <img  class="img-responsive" src="<?php echo e(asset(Storage::url($vision->preview_image))); ?>" alt="">
        <?php endif; ?>
        
          <?php echo $vision->post_content; ?>


        
      </div>

      <br>
      <hr>
      <br>

      <div class="col-sm-12" id="values">
        <h2><?php echo e($values->post_title); ?></h2>
        <br><br>
        <?php if($values->preview_image != ""): ?>
        <img  class="img-responsive" src="<?php echo e(asset(Storage::url($values->preview_image))); ?>" alt="">
        <?php endif; ?>
        
          <?php echo $values->post_content; ?>


        
      </div>

     
      <br>
      <hr>
      <br>

      <div class="col-sm-12" id="our_team">
        <h2><?php echo e($our_team->post_title); ?></h2>
        <br><br>
        <?php if($our_team->preview_image != ""): ?>
        <img  class="img-responsive" src="<?php echo e(asset(Storage::url($our_team->preview_image))); ?>" alt="">
        <?php endif; ?>
        
          <?php echo $our_team->post_content; ?>


        
      </div>



    </div>
  </div>
</section>				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>