<?php $__env->startSection('content'); ?>  
<div class="row">
	<div class="col-sm-8 col-sm-offset-2 col-xs-12">

		<div class="x_panel">
			<div class="x_title">
				<h2 style="text-transform: uppercase;">Add New <?php echo e(str_replace("_"," ", str_replace("f__", "", $type) )); ?></h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<br />
				<?php echo Form::open(["route"=>"posts.store", "id" => "demo-form2", "files" => true, "class" => "form-horizontal form-label-left form-group", "data-parsley-validate row" => ""]); ?>


					    <?php echo e(Form::label('post_title', 'Post Title:')); ?>

					    <?php echo e(Form::text('post_title', null, array("class" => "form-control", "maxlength" => "191" ))); ?>

					    <br>

					    <?php echo e(Form::hidden('post_type', $type,array("class" => "form-control post_type_class" ) 
						)); ?>

						<br>


					    <?php echo e(Form::label('post_content', 'content', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::textarea('post_content', null, array("class" => "form-control" ))); ?>

					    <br>


					    <?php echo e(Form::label('file', 'Preview Image:', array('class' => ' form-margin'))); ?>

					    <?php echo e(Form::file('file', null, array("class" => "form-control", "maxlength" => "10" ))); ?>		
					    <br>				

					    <?php echo e(Form::submit('Save', array('class' => 'btn btn-lg btn-block btn-primary form-margin'))); ?>


				<?php echo Form::close(); ?>


			</div>
		</div>


	</div>
</div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_page_script'); ?>
	<script type="text/javascript">
		$(document).ready(function(){

			var postType = $(".post_type_class").val();

			if(postType == "slider"){
				$("label[for=post_content]").hide();
				$("textarea[name=post_content]").hide();
			}else if(postType == "service"){
				$("label[for=file]").hide();
				$("input[name=file]").hide();
			}else if(postType == "contact"){
				$("label[for=file]").hide();
				$("input[name=file]").hide();
			}

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>