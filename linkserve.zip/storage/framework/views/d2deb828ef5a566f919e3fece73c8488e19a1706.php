<?php $__env->startSection('content'); ?>  
<section class="well1 ins2 mobile-center">
  <div class="container">
    <h2>Article: <?php echo e($type); ?></h2>
	
    <?php $cnt=0;?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($cnt%3==0): ?>
        <div class="row ">
      <?php endif; ?>

        <div class="col-sm-4"><img src="<?php echo e(asset(Storage::url($post->preview_image))); ?>" alt="">
          <h3><?php echo e($post->post_title); ?></h3>
          <p class="text-justify">
            <?php echo e(substr($post->post_content, 0, 200)); ?>

            <?php if(strlen($post->post_content) >200): ?>
              ...
            <?php endif; ?>
          </p><a href="#" class="btn">Read more</a>
        </div>

      <?php $cnt++;?>
      <?php if(($cnt%3==0) && (!$loop->last)): ?>
        </div>
        <hr>
      <?php elseif(($cnt%3 != 0) && ($loop->last)): ?>
        </div>

      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="text-center">
    <?php echo $posts->links();; ?>

    </div>



  </div>
</section>				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>