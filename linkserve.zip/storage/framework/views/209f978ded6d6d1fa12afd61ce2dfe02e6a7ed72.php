<?php $__env->startSection('content'); ?>  
<div class="row">
	<div class="col-sm-8 col-sm-offset-2 col-xs-12">

		<div class="x_panel">
			<div class="x_title">
				<h2 style="text-transform: uppercase;">Add New 4 Home Block</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<br />
				<?php echo Form::open(["url"=> url('admin/storeHomeSocialLinks'), "id" => "demo-form2", "files" => true, "class" => "form-horizontal form-label-left form-group", "data-parsley-validate row" => ""]); ?>


					    <?php echo e(Form::label('facebook', 'Facebook :')); ?>

					    <?php echo e(Form::text('facebook', null, array("class" => "form-control", "maxlength" => "191", "required" => "required" ))); ?>

					    <br>

			

						<?php echo e(Form::label('twitter', 'Twitter :')); ?>

					    <?php echo e(Form::text('twitter', null, array("class" => "form-control", "maxlength" => "191", "required" => "required" ))); ?>

					    <br>

			

						<?php echo e(Form::label('instagram', 'Instagram :')); ?>

					    <?php echo e(Form::text('instagram', null, array("class" => "form-control", "maxlength" => "191", "required" => "required" ))); ?>

					    <br>

				

					    <?php echo e(Form::submit('Save', array('class' => 'btn btn-lg btn-block btn-primary form-margin'))); ?>


				<?php echo Form::close(); ?>


			</div>
		</div>


	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>