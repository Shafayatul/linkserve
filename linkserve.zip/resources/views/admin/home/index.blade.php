@extends('admin.master')
@section('content')  
<div class="row">
	<div class="col-sm-12" style="min-height: 100vh">

		<br>
		<br>
		<br>
		<br>
		<h1 class="welcome-text"> Welcome To <br> <br> Link Serve Admin</h1>


	</div>
</div>


@endsection

